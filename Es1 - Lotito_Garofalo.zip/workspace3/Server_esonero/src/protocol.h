/*
 * protocol.h
 *
 *  Created on: 22 nov 2022
 *      Author: simone Lotito, Marco Garofalo
 */


#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#define PROTO_PORT 60000
#define BUFFER_SIZE 128
#define QLEN 5
#define NO_ERROR 0

typedef struct {
	char operand;
	int number1;
	int number2;
} msg;

typedef struct {
	int result;
} res;


int add(int num1, int num2){
	return num1 + num2;
}

int mult(int num1, int num2){
	return num1 * num2;
}

int sub(int num1, int num2){
	return num1 - num2;
}

int division(int num1, int num2){

	return num1 / num2;
}



int operate (char operand, int num1, int num2){
	int res = 0;
	switch (operand) {
	case '+':
		res=add(num1, num2);
		break;
	case '-':
		res = sub (num1, num2);
		break;
	case '/':
		res = division (num1, num2);
		break;
	case 'x':
	case 'X':
	case '*':
		res = mult (num1, num2);
		break;
	default:
		break;
	}
	return res;
}


#endif /* PROTOCOL_H_ */
